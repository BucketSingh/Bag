var TollBooth = /** @class */ (function () {
    function TollBooth() {
        this.totalCar = 0;
        this.totalCash = 0;
    }
    TollBooth.prototype.processInput = function () {
        var input = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            input[_i] = arguments[_i];
        }
        for (var i = 0; i < input.length; i++) {
            var action = input[i];
            if (action == "p") {
                this.payingCar();
            }
            else if (action == "n") {
                this.noPayingCar();
            }
        }
    };
    TollBooth.prototype.payingCar = function () {
        this.totalCash += 50;
        this.totalCar += 1;
    };
    TollBooth.prototype.noPayingCar = function () {
        this.totalCar += 1;
    };
    TollBooth.prototype.display = function () {
        console.log("Total Car gone ".concat(this.totalCash));
        console.log("Total Car gone ".concat(this.totalCar));
    };
    return TollBooth;
}());
var tb = new TollBooth();
tb.processInput("p", "n", "p", "n");
tb.display();
