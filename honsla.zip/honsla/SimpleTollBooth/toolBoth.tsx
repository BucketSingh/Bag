
class TollBooth{
  private totalCar:number;
  private totalCash :number;

  public constructor(){
    this.totalCar=0;
    this.totalCash = 0;
  }




    public processInput(...input:string[]){
        for(let i =0;i<input.length;i++){
            const action = input[i];
            if(action=="p"){
                this.payingCar();
            }
            else if(action =="n"){
                this.noPayingCar();
            }
        }
    }
    public payingCar():void{
        this.totalCash+=50;
        this.totalCar+=1;

    }
    public noPayingCar():void{
        this.totalCar+=1;
    }
    public display():void{
        console.log(`Total Car gone ${this.totalCash}`);
        console.log(`Total Car gone ${this.totalCar}`);
    }

 




}

let tb = new TollBooth();
tb.processInput("p","n","p","n");
tb.display();


