var SafeArrayV = /** @class */ (function () {
    function SafeArrayV() {
        this.array = new Array(5);
        this.WrongIndex = new Array(0);
    }
    SafeArrayV.prototype.putElement = function (index, value) {
        if (index >= 0 && index <= this.array.length) {
            this.array[index] = value;
        }
        else {
            this.failedTest(index);
        }
    };
    SafeArrayV.prototype.getElement = function (index) {
        if (index >= 0 && index <= this.array.length) {
            return this.array[index];
        }
        else {
            return -1;
        }
    };
    SafeArrayV.prototype.failedTest = function (index) {
        this.WrongIndex.push(index);
    };
    SafeArrayV.prototype.displayfailed = function () {
        console.log("No of failed Event is ".concat(this.WrongIndex.length, " and indexes are ").concat(this.WrongIndex, " "));
    };
    return SafeArrayV;
}());
var obj = new SafeArrayV();
obj.putElement(3, 160);
console.log("element " + obj.getElement(3));
obj.putElement(7, 179);
obj.displayfailed();
obj.putElement(82, 342);
obj.displayfailed();
console.log("End");
// The first, putElement(index, value), that takes an index number and an number type value as arguments and inserts the number typevalue into the array at the index
// The second.getElement(index), takes an index number as an argument and returns the number type value
