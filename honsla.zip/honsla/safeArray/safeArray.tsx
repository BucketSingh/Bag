class SafeArrayV{
    private array:number[];
    private WrongIndex:number[];

    public constructor(){
        this.array = new Array(5);
        this.WrongIndex = new Array(0);
    }
     public putElement(index:number ,value:number){
        if(index>=0 && index<=this.array.length){
            this.array[index] = value;
        }
        else{
            this.failedTest(index);
        }
     }

     public getElement(index:number):number{
        if(index>=0 && index<=this.array.length){
          return this.array[index];
        }
       else{ return -1;
       }
     }
     public failedTest(index:number){
        this.WrongIndex.push(index);
     }
     public displayfailed(){
        console.log(`No of failed Event is ${this.WrongIndex.length} and indexes are ${this.WrongIndex} `)
        
     }
}



let obj = new SafeArrayV();
obj.putElement(3,160);
console.log("element "+obj.getElement(3));
obj.putElement(7,179);
obj.displayfailed();
obj.putElement(82,342);
obj.displayfailed();
console.log("End");
// The first, putElement(index, value), that takes an index number and an number type value as arguments and inserts the number typevalue into the array at the index

// The second.getElement(index), takes an index number as an argument and returns the number type value