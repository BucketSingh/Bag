import React from 'react';
const Home=()=>{

    return (
        <>
        <div className="container">
	

	<h3>Home</h3>
	<h4>Welcome to Home PAge</h4>
	
</div>
        </>
    )
}
export default Home;
