import { title } from "process";
import React,{useState} from "react";

type data={
    title:string;
    image:string;
    price:number;
    description:string;
}

const dataValue:data[]=[
    {title:"Product1",
    image:"https://picsum.photos/200",
    price:380,
    description:"first product"},
     {title:"Product2",
     image:"https://picsum.photos/200",
     price:980, description:"second product"}, 
     {title:"Product3",
     image:"https://picsum.photos/200",
     price:1200,
     description:"third product"}


]
  const Display=()=>{
    const [selectProduct,setSelectedProduct] = useState<string>("");
    const handleEvent  = (event:React.ChangeEvent<HTMLSelectElement>)=>{
        setSelectedProduct(event.target.value);
    }

    return <div>
        {dataValue.map((value)=>(
            <span><img src={value.image}/><br/>
                <h2>{value.title}  Price:{value.price}</h2>
            </span>
        ))}
        <select value={selectProduct} onChange={handleEvent}>
            <option value="" >Select Product
            </option>
            {dataValue.map((value)=>(
                <option key={value.title} value={value.title}>{value.title}</option>
            ))}
        </select>
        {selectProduct && <div>
           {dataValue.map((index)=>{
            if(index.title==selectProduct){
            return <div id={index.title}>{index.description}</div>
            }
           })}
          
            </div>}
    </div>
  }

  export default Display;

// [{"title":"Product1","image":"https://picsum.photos/200","price":380,"description":"first product"}, {"title":"Product2","image":"https://picsum.photos/200","price":980, "description":"second product"). {"title":"Product3","image":"https://picium.photos/200","price":1200,"description":"third product}]

// perform the task as per user story

// User Story 1: Display all the products in UI

// User Story 2: Display all the product name in select (drop down)

// User Story 3: On selecting any product from the list display the product details of selected product only.