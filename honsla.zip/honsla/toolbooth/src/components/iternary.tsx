import React,{useState} from 'react';
type Itineray={
    [day:string]:string[];
}

const itenraryData:Itineray={
    'day 1': ['Reach the destination'],
    'day 2': ['City Tour in a company tourist bus', 'Breakfast & Dinner'],
    'day 3': ['Visit Chang-La'],
    'day 4': ['Back to your home'],
}

const ItneraryObj=()=>{
    const [selectday,setSelectedDay] = useState<string>("");
    const handleDaySelect = (event:React.ChangeEvent<HTMLSelectElement>)=>{
        setSelectedDay(event.target.value);
    }

   return <div>
    <select value={selectday} onChange={handleDaySelect}>
        <option value="">Select a Day</option>
        {Object.keys(itenraryData).map((day)=>(
            <option key={day} value={day}>{day}</option>
        )

        )}
        </select>
        {selectday && (<div>
            {itenraryData[selectday].map((content,index)=>(
                <p key={index}>{content}</p>
            ))}
        </div>)}
    
   </div>
}
export default ItneraryObj;




//       </select>
//       {selectedDay && (
//         <div>
//           {itineraryData[selectedDay].map((content, index) => (
//             <p key={index}>{content}</p>
//           ))}
//         </div>
//       )}
//     </div>

