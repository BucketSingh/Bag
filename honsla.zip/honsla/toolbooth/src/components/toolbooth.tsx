import React,{useState} from "react";

type TollBoothProps = {
   input:string[]; 
}

const TollBooth=(props:TollBoothProps)=>{
    var payCar:number = 0;
    var carTotal:number = 0;

    console.log(props.input);
  

    const processInput=(arr:string[])=>{
        arr.forEach((data)=>{
            const action = data;
            if(action=="p"){
                payingCar();
            }
            else if(action =="n"){
                noPayingCar();
            }
        })
    }
    const payingCar=()=>{
       payCar+=50;
       carTotal+=1;
    }
    const noPayingCar=()=>{
        carTotal+=1;
    }
    const display=()=>{
        console.log(`Total Car gone ${carTotal}`);
        console.log(`Total Car gone ${payCar}`);
    }

    processInput(props.input);
    display();

 return <div></div>;
}

export default TollBooth;




