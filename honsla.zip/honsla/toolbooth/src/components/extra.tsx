import React from 'react';

type CartItem = {
  title: string;
  price: number;
};

type AppState = {
  cartItems: CartItem[];
};

class Cart extends React.Component<{}, AppState> {
  constructor(props: {}) {
    super(props);
    this.state = {
      cartItems: [],
    };
  }

  componentDidMount() {
    this.fetchCartItems();
  }

  fetchCartItems = () => {
    fetch('https://www.baljeetmatta.com/codequotient/Questions/getJSON')
      .then((response) => response.json())
      .then((data) => {
        this.setState({ cartItems: data });
      })
      .catch((error) => {
        console.error('Error fetching cart items:', error);
      });
  };

  handleRemoveItem = (title: string) => {
    this.setState((prevState) => ({
      cartItems: prevState.cartItems.filter((item) => item.title !== title),
    }));
  };

  render() {
    const { cartItems } = this.state;

    return (
      <div>
        <h1>Cart Items</h1>
        <ul>
          {cartItems.map((item, index) => (
            <li key={index}>
              <span>{item.title}</span>
              <span> - ${item.price}</span>
              <button onClick={() => this.handleRemoveItem(item.title)}>Remove</button>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default Cart;
class Account {
    private transactions: number;
    constructor() {
      this.transactions = 0;
    }
  
    process(value: number): void {
      // Process the transaction
      console.log(`Processing transaction: ${value}`);
      this.transactions++;
    }
  }
  
  class FilteredAccount extends Account {
    private filteredTransactions: number;
  
    constructor() {
      super();
      this.filteredTransactions = 0;
    }
  
    process(value: number): void {
      if (value !== 0) {
        super.process(value);
      } else {
        console.log("Zero-valued transaction approved but not processed");
        this.filteredTransactions++;
      }
    }
  
    getFilteredCount(): number {
      return this.filteredTransactions;
    }
  }
  
  // Usage example
  const filteredAcc = new FilteredAccount();
  filteredAcc.process(100); // Process the transaction: 100
  filteredAcc.process(0); // Zero-valued transaction approved but not processed
  filteredAcc.process(-50); // Process the transaction: -50
  
  console.log(filteredAcc.getFilteredCount()); // Output: 1
  


  //stopwach
  import React, { useState, useRef } from 'react';

type Lap = {
  id: number;
  time: number;
};

const Stopwatch: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [time, setTime] = useState(0);
  const [laps, setLaps] = useState<Lap[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const lapIdRef = useRef(1);

  const formatTime = (time: number): string => {
    const minutes = Math.floor(time / 60000);
    const seconds = Math.floor((time % 60000) / 1000);
    const milliseconds = Math.floor((time % 1000) / 10);

    return `${minutes.toString().padStart(2, '0')}:${seconds
      .toString()
      .padStart(2, '0')}.${milliseconds.toString().padStart(2, '0')}`;
  };

  const handleStartStop = () => {
    if (isRunning) {
      clearInterval(timerRef.current as NodeJS.Timeout);
    } else {
      const startTime = Date.now() - time;
      timerRef.current = setInterval(() => {
        setTime(Date.now() - startTime);
      }, 10);
    }

    setIsRunning((prevState) => !prevState);
  };

  const handleLap = () => {
    const newLap: Lap = {
      id: lapIdRef.current,
      time,
    };

    setLaps((prevState) => [...prevState, newLap]);
    lapIdRef.current++;
  };

  const handleReset = () => {
    clearInterval(timerRef.current as NodeJS.Timeout);
    setIsRunning(false);
    setTime(0);
    setLaps([]);
    lapIdRef.current = 1;
  };

  return (
    <div>
      <h1>Stopwatch</h1>
      <div>
        <span>{formatTime(time)}</span>
      </div>
      <div>
        <button onClick={handleStartStop}>{isRunning ? 'Stop' : 'Start'}</button>
        <button onClick={handleLap}>Lap</button>
        <button onClick={handleReset}>Reset</button>
      </div>
      <div>
        <h2>Laps:</h2>
        <ul>
          {laps.map((lap) => (
            <li key={lap.id}>{formatTime(lap.time)}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Stopwatch;


//cart
import React, { useState } from 'react';

type Product = {
  name: string;
  price: number;
};

const ProductForm: React.FC = () => {
  const [productName, setProductName] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [cart, setCart] = useState<Product[]>([]);
  const products: Product[] = [
    { name: 'Product 1', price: 100 },
    { name: 'Product 2', price: 200 },
    { name: 'Product 3', price: 300 },
  ];

  const handleNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setProductName(event.target.value);
  };

  const handlePriceChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setProductPrice(event.target.value);
  };

  const handleAddToCart = () => {
    const newProduct: Product = {
      name: productName,
      price: Number(productPrice),
    };
    setCart((prevCart) => [...prevCart, newProduct]);
    setProductName('');
    setProductPrice('');
  };

  return (
    <div>
      <h1>Product Form</h1>
      <div>
        <label>Product Name:</label>
        <input type="text" value={productName} onChange={handleNameChange} />
      </div>
      <div>
        <label>Product Price:</label>
        <input type="number" value={productPrice} onChange={handlePriceChange} />
      </div>
      <div>
        <button onClick={handleAddToCart}>Add to Cart</button>
      </div>
      <div>
        <h2>Products:</h2>
        <select>
          {products.map((product, index) => (
            <option key={index} value={product.name}>
              {product.name}
            </option>
          ))}
        </select>
      </div>
      <div>
        <h2>Cart:</h2>
        <ul>
          {cart.map((product, index) => (
            <li key={index}>
              {product.name} - {product.price}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ProductForm;


//stopwatch
import React from 'react';

type StopwatchState = {
  isRunning: boolean;
  startTime: number;
  currentTime: number;
  laps: number[];
};

class Stopwatch extends React.Component<{}, StopwatchState> {
  intervalId: NodeJS.Timeout | null = null;

  constructor(props: {}) {
    super(props);
    this.state = {
      isRunning: false,
      startTime: 0,
      currentTime: 0,
      laps: [],
    };
  }

  componentWillUnmount() {
    this.stopTimer();
  }

  startTimer = () => {
    if (!this.state.isRunning) {
      const startTime = Date.now() - this.state.currentTime;
      this.setState({
        isRunning: true,
        startTime,
      });

      this.intervalId = setInterval(() => {
        this.setState({
          currentTime: Date.now() - this.state.startTime,
        });
      }, 10);
    }
  };

  stopTimer = () => {
    if (this.state.isRunning) {
      if (this.intervalId) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
      this.setState({
        isRunning: false,
      });
    }
  };

  lapTimer = () => {
    if (this.state.isRunning) {
      this.setState((prevState) => ({
        laps: [...prevState.laps, prevState.currentTime],
      }));
    }
  };

  render() {
    const { isRunning, currentTime, laps } = this.state;

    const formattedTime = new Date(currentTime).toISOString().slice(11, -1);

    return (
      <div>
        <h1>Stopwatch</h1>
        <div>
          <p>Time: {formattedTime}</p>
          <button onClick={this.startTimer} disabled={isRunning}>
            Start
          </button>
          <button onClick={this.stopTimer} disabled={!isRunning}>
            Stop
          </button>
          <button onClick={this.lapTimer} disabled={!isRunning}>
            Lap
          </button>
          <h2>Laps</h2>
          <ul>
            {laps.map((lapTime, index) => (
              <li key={index}>{new Date(lapTime).toISOString().slice(11, -1)}</li>
            ))}
          </ul>
        </div>
      </div>
    );
  }
}

export default Stopwatch;
