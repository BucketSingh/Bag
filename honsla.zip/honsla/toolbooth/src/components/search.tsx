import React,{useState} from "react";
import { title } from 'process';

type data ={
    title:string;
    author:string;
}

const dataValue:data[]=
    
[
    {title:"my Talented book",author:"ABC"},
    {title:"My Third Book",  author:"CDE"}
]

const Searchbox=()=>{
    const [searchdata,setSearch] = useState<string>("");
    const handleChange = (event:React.ChangeEvent<HTMLInputElement>)=>setSearch(event.target.value);
    const filterSeach = dataValue.filter((data)=>
    data.title.toLowerCase().includes(searchdata.toLowerCase())
    )
    return <div>
        <input type="text" value={searchdata} onChange={handleChange}/>
        {filterSeach.map((book)=>(
            <div key={book.title}>{book.title} - {book.author}</div>
        ))}
    </div>
}

export  default Searchbox;