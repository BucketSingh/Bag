import React from 'react';
import logo from './logo.svg';

import TollBooth from './components/toolbooth';
import ItneraryObj from './components/iternary';
import Display from './components/displayPic';
import Searchbox from './components/search';

function App() {
  return (
    <div>
      <TollBooth input={["p","p","n","p","p","n","p"]}></TollBooth>
    {/* <ItneraryObj /> */}
    {/* <Display /> */}
    <Searchbox />
    </div>
  );
}

export default App;

//React+typescript
//npm create-react-app name --template typescript

//Typescript
//tsc filename.tsc
//tsc -init